"""

OOP - Object Oriented Programming

programming oriented around objects ;)

"""

x = 4

print(type(x))