from user import User


""" a = User("Agnes")
b = User("Katie")
c = User("Jack")


print("id", a.id)  # 1
print("id", b.id)  # 2
print("id", c.id)  # 3
print("next id: ", User.id)
 """

users = [User() for __ in range(20)]

for user in users:
    print(user.id)

print("NEXT ID: ", User.nextId)
