""" 
     association - mapping meaning: belongs to, is one of the components, is part of something

     Aggregation - combine, concatenate, accumulate - create a component object

     Composition - same as aggregation with ONE CONDITION - the object that we assign cannot exist without the class to which this object is assigned to

     Inheritance vs association - when to use which?
     
     If object is PART of another object use association
     If object is SUBTYPE of another object use inheritance

     BankAccount HAS users - association
     BankAcount has many types of bank accounts like MinimumBalanceAccoount - inheritance
     
"""


class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def count_surface_area(self):
        return self.width * self.height


class Square(Rectangle):
    def __init__(self, sideLength):
        super().__init__(sideLength, sideLength)


""" 
class Cube():
    def __init__(self, square: Square):
        self.square = square

    def count_surface_area(self):
        return self.square.count_surface_area() * 6

    def count_volume(self):
        return self.square.count_surface_area() * self.square.height
 """


class Cuboid():
    def __init__(self, figure, height):
        self.base = figure
        self.height = height

    def count_volume(self):
        return self.base.count_surface_area() * self.height

    def count_surface_area(self):
        return 2 * self.base.count_surface_area() + 2 * self.base.width * self.height + 2 * self.base.height * self.height


class Cube(Cuboid):
    def __init__(self, figure: Square):
        super().__init__(figure, figure.height)


cube = Cube(Square(4))

print(cube.count_volume())
