"""
linter - program that informs about stylish type of errors so errors that will let your program "pass" (run)
however your program won't be "stylish" which means it doesn't follow rules set by linter
  

"""

rooms = {49: 'Arkadiusz Włodarczyk', 69: 'Wioletta Włodarczyk'}

a = {'name': 'Arkadiusz', 'surname': 'Włodarczyk', 'name': "Wiola"} 

 

sam = 4
sampleNumber = 4;


def get_number():
    return 5