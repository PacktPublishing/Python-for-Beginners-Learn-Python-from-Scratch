"""

OOP - Object Oriented Programming

Object

    Objects - containers that stores variables and functions thematically
                connected to each other for easier future usage
    Classes - blueprint for creating instances (copies) of objects     
            

Attributes - fields/features
Methods - functions (behaviors of objects, for example, the dog can bark)

Instance of class - instance means 'case', 'example', 'pattern' that can differ from other 'cases'

                     that 
                    came out of blueprint (class) 

                    so it's another name for OBJECT

                START the name of your classes with uppercase!

"""


class User:
    age = 0


john = User()
jessica = User()

john.age = 15


age = 50

print(john.age)
print(jessica.age)
