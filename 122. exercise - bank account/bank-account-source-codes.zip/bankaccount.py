class BankAccount():
    def __init__(self):
        self.balance = 0

    def deposit(self, amount):
        """ lets check if the money sent to method is legal """
        self.balance += amount

    def withdraw(self, amount):
        if (self.balance > amount):
            self.balance -= amount

    def __str__(self):
        return str(self.balance)
