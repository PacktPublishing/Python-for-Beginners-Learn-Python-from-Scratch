from bankaccount import BankAccount


account = BankAccount()


account.deposit(1000)


account.withdraw(500000)


print(account)
