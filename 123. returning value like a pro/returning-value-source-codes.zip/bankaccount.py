class Result():
    def __init__(self, success, message, value=None):
        self.isSuccess = success
        self.message = message
        self.value = value


class BankAccount():
    def __init__(self, balance=0):
        self.balance = balance

    def deposit(self, amount):
        """ lets check if the money sent to method is legal """
        self.balance += amount

    def try_withdraw(self, amount):
        if (self.balance > amount):
            self.balance -= amount
            return Result(True, "The cash has been withdrawn", amount)

        return Result(False, "Not Enough money")

    def __str__(self):
        return str(self.balance)
