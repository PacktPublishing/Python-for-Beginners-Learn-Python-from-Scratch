""" class variables static """


class User:
    nextId = 1  # class variable - static

    def __init__(self, name=""):
        self.name = name
        self.id = User.nextId
        User.nextId += 1
