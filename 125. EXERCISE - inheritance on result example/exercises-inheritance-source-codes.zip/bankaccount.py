from result import Ok, Error


class BankAccount():
    def __init__(self, balance=0):
        self.balance = balance
        # WHATEVER NEW ADDED HERE

    def deposit(self, amount):
        """ lets check if the money sent to method is legal """
        print("im from parent class BankAccount")
        self.balance += amount

    def try_withdraw(self, amount):
        if (self.balance > amount):
            self.balance -= amount
            """ SOME NEW CODE """
            return Ok("The cash has been withdrawn", amount)

        return Error("Not Enough money")

    def __str__(self):
        return str(self.balance)


class MinimumBalanceAccount(BankAccount):
    def __init__(self, balance=1000, minimumBalance=500):
        super().__init__(balance)
        self.minimumBalance = minimumBalance

    def try_withdraw(self, amount):
        if(self.balance - amount >= self.minimumBalance):
            return super().try_withdraw(amount)
        else:
            return Error("You tried to pass the threshold", amount)


""" INHERITANCE 

     MONSTER
       hp
       defense

  ZOMBIE SKELETON


"""
