"""
    Objects - containers that stores variables and functions thematically
                connected to each other for easier future usage
    Classes - blueprint for creating instances (copies) of objects                 

Attributes - fields/features
Methods - functions (behaviors of objects, for example, the dog can bark)

Instance of class - instance means 'case', 'example', 'pattern' that can differ from other 'cases'
                            that 
                    came out of blueprint (class) 

                    so it's another name for OBJECT

    self - this
"""
age = 70


class User:
    age = 0
    name = "unknown"

    def print_age(self, additional_message):
        print(self.name, "age", self.age, additional_message)


listOfUsers = [User(), User()]


listOfUsers[0].age = 20
listOfUsers[1].age = 10

listOfUsers[0].name = "John"
listOfUsers[1].name = "Jessica"

listOfUsers[0].print_age("something")


user1 = User()
user2 = User()

user1.age = 15
user1.name = "John"

user2.name = "Jessica"

user1.print_age("Something new")
user2.print_age("whatever")


def print_age(age, name):
    print(name, "age: ", age)


name = "Peter"

print_age(age, name)
