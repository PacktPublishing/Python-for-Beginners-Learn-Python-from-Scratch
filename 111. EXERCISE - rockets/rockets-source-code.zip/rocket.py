from random import randint


class Rocket:
    def __init__(self, speed=1):
        self.altitude = 0
        self.speed = speed

    def moveUp(self):
        self.altitude += 1


rockets = [Rocket(randint(1, 6)) for __ in range(5)]


for __ in range(10):
    rocketIndexToMove = randint(0, len(rockets) - 1)
    rockets[rocketIndexToMove].moveUp()


for rocket in rockets:
    print(rocket.altitude)
