import math

def area_of_square(a):
    return a * a

def area_of_rectangle(a, b):
    return a * b

def area_of_circle(r):
    return math.pi * r ** 2

def area_of_triangle(a, h):
    return 0.5 * a * h

def area_of_trapeze(a, b, h):
    return (a + b) / 2 * h
    

