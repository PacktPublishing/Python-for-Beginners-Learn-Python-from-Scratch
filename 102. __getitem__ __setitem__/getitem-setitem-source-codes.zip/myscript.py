from rocket import RocketBoard

boardOfRockets = RocketBoard(4)


boardOfRockets[0] = 50


print(boardOfRockets[0])
