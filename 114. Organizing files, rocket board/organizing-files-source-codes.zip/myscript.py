from rocket import RocketBoard

board = RocketBoard(2)


print(board.rockets[0].altitude)
