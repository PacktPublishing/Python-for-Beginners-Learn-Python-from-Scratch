# docstring DOCument string

from random import randint


class Rocket:
    """represents the rocket that can moveUp with set speed
    """

    def __init__(self, speed=1):
        """

        Keyword Arguments:
            speed {int} -- speed of rocket's engine - how fast the rocket flies (default: {1})
        """
        self.altitude = 0
        self.speed = speed

    def moveUp(self):
        """it moves up the rocket by set speed amount
        """
        self.altitude += self.speed


rockets = [Rocket(randint(1, 6)) for __ in range(5)]


for __ in range(10):
    rocketIndexToMove = randint(0, len(rockets) - 1)
    rockets[rocketIndexToMove].moveUp()


for rocket in rockets:
    print(rocket.altitude)

rocket = Rocket()
