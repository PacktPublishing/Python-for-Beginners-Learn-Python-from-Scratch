from rocket import RocketBoard, Rocket

boardOfRockets = RocketBoard(4)

#boardOfRockets[0].x = 3


myRocket = Rocket(altitude=3, x=4)

print(boardOfRockets[0].get_distance(myRocket))
