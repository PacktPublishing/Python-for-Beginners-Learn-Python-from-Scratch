from rocket import RocketBoard


board = RocketBoard(2)

print(len(board))
