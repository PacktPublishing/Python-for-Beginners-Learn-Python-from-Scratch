from rocket import RocketBoard, Rocket


myRocket = Rocket(altitude=3, x=4)
anotherRocket = Rocket(altitude=1, x=30)


x: float = RocketBoard.get_distance(myRocket, anotherRocket)


print(x)
