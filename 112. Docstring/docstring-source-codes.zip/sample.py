"""
__init__ - initialization - means setting starting values for attributes

in other languages __init__ is called CONSTRUCTOR

"""


class User:

    def __init__(self, age, name):
        print("I will be invoked whenever you construct an object")
        print(age)
        self.age = age
        age = 2222222222222
        print(age)
        self.name = name

    def print_age(self, additional_message):
        print(self.name, "age", self.age, additional_message)


user1 = User(15, "John")
user2 = User(40, "Jessica")


user1.print_age("Something new")
user2.print_age("whatever")
