from random import randint


class Rocket:
    """represents the rocket that can moveUp with set speed
    """

    def __init__(self, speed=1):
        """

        Keyword Arguments:
            speed {int} -- speed of rocket's engine - how fast the rocket flies (default: {1})
        """
        self.altitude = 0
        self.speed = speed

    def moveUp(self):
        """it moves up the rocket by set speed amount
        """
        self.altitude += self.speed

    def __str__(self):
        return "Current altitude of rocket is: " + str(self.altitude)


class RocketBoard:
    def __init__(self, amountOfRockets=5):
        self.rockets = [Rocket(randint(1, 6)) for __ in range(amountOfRockets)]

        for __ in range(10):
            rocketIndexToMove = randint(0, len(self.rockets) - 1)
            self.rockets[rocketIndexToMove].moveUp()

        for rocket in self.rockets:
            print(rocket)

    def __getitem__(self, key):
        return self.rockets[key]

    def __setitem__(self, key, value):
        self.rockets[key].altitude = value
